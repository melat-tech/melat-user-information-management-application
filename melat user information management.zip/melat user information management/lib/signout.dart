
class Constants{

  static const String signOut = 'sign out';

  static const List<String> choices = <String>[
    signOut
  ];
}